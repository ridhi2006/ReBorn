import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { analyzeProductImage, getReuseSuggestions, chatWithAI } from "./gemini";

// Configure multer for image uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Image upload and analysis endpoint
  app.post("/api/upload-product", upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const imageBase64 = req.file.buffer.toString('base64');
      const mimeType = req.file.mimetype;

      // Analyze the image
      const analysis = await analyzeProductImage(imageBase64, mimeType);

      res.json({
        success: true,
        analysis,
        imageUrl: `data:${mimeType};base64,${imageBase64}`, // In production, upload to Firebase Storage
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      res.status(500).json({ message: error.message || "Failed to process image" });
    }
  });

  // Get AI reuse suggestions
  app.post("/api/get-reuse-suggestions", async (req, res) => {
    try {
      const { productDescription, imageBase64, mimeType } = req.body;

      if (!productDescription) {
        return res.status(400).json({ message: "Product description is required" });
      }

      const suggestions = await getReuseSuggestions(productDescription, imageBase64, mimeType);

      res.json({
        success: true,
        ...suggestions,
      });
    } catch (error: any) {
      console.error('Suggestions error:', error);
      res.status(500).json({ message: error.message || "Failed to get suggestions" });
    }
  });

  // AI chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, conversationHistory } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const history = conversationHistory || [];
      const response = await chatWithAI(message, history);

      res.json({
        success: true,
        response,
      });
    } catch (error: any) {
      console.error('Chat error:', error);
      res.status(500).json({ message: error.message || "Chat failed" });
    }
  });

  // Get YouTube search results (using YouTube Data API would require additional setup)
  // For now, we'll return YouTube search URLs
  app.post("/api/youtube-search", async (req, res) => {
    try {
      const { searchTerms } = req.body;

      if (!searchTerms || !Array.isArray(searchTerms)) {
        return res.status(400).json({ message: "Search terms array is required" });
      }

      const youtubeLinks = searchTerms.map((term: string) => ({
        searchTerm: term,
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(term)}`,
        embedUrl: `https://www.youtube.com/embed/?search_query=${encodeURIComponent(term)}`,
      }));

      res.json({
        success: true,
        links: youtubeLinks,
      });
    } catch (error: any) {
      console.error('YouTube search error:', error);
      res.status(500).json({ message: error.message || "Search failed" });
    }
  });

  // Placeholder endpoints for future Firebase Firestore integration
  
  // Get user profile
  app.get("/api/user/:userId", async (req, res) => {
    try {
      // TODO: Fetch from Firestore
      res.json({
        success: true,
        user: {
          id: req.params.userId,
          ecoPoints: 0,
          productsReused: 0,
          co2Saved: 0,
          repairsCompleted: 0,
        },
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get repairers
  app.get("/api/repairers", async (req, res) => {
    try {
      // TODO: Fetch from Firestore
      res.json({
        success: true,
        repairers: [],
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create repairer profile
  app.post("/api/repairers", async (req, res) => {
    try {
      const { userId, skills, bio, location, phone, email } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Repairer profile created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get marketplace items
  app.get("/api/marketplace", async (req, res) => {
    try {
      // TODO: Fetch from Firestore
      res.json({
        success: true,
        items: [],
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create marketplace item
  app.post("/api/marketplace", async (req, res) => {
    try {
      const { repairerId, title, description, price, imageUrl, category, condition } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Marketplace item created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create repair request
  app.post("/api/repair-requests", async (req, res) => {
    try {
      const { userId, repairerId, productId, description } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Repair request created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Award EcoPoints
  app.post("/api/eco-points", async (req, res) => {
    try {
      const { userId, points, reason } = req.body;
      
      // TODO: Save to Firestore and update user's total
      res.json({
        success: true,
        message: "EcoPoints awarded successfully",
        newTotal: points,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
