// Gemini AI integration for product analysis and reuse suggestions
import { GoogleGenAI } from "@google/genai";

if (!process.env.GEMINI_API_KEY) {
  throw new Error('Missing required GEMINI_API_KEY');
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeProductImage(imageBase64: string, mimeType: string): Promise<string> {
  try {
    const contents = [
      {
        inlineData: {
          data: imageBase64,
          mimeType: mimeType,
        },
      },
      `Analyze this product image and identify what it is. Provide a brief description of the item, its condition, and what type of product it appears to be. Be specific and concise.`,
    ];

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contents,
    });

    return response.text || "Could not analyze the image";
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw new Error(`Failed to analyze image: ${error}`);
  }
}

export async function getReuseSuggestions(productDescription: string, imageBase64?: string, mimeType?: string): Promise<{
  suggestions: string[];
  youtubeSearchTerms: string[];
  canBeRepaired: boolean;
}> {
  try {
    let contents: any[] = [];
    
    if (imageBase64 && mimeType) {
      contents.push({
        inlineData: {
          data: imageBase64,
          mimeType: mimeType,
        },
      });
    }

    const prompt = `Based on this product ${imageBase64 ? 'in the image' : ''}: ${productDescription}

Provide creative and practical reuse ideas for this item. For each suggestion:
1. Give a specific, actionable reuse idea
2. Suggest a YouTube search term that would help someone learn how to do it

Also determine if this item can be professionally repaired.

Respond in this exact JSON format:
{
  "suggestions": ["idea 1", "idea 2", "idea 3"],
  "youtubeSearchTerms": ["search term 1", "search term 2", "search term 3"],
  "canBeRepaired": true/false
}`;

    contents.push(prompt);

    const response = await ai.models.generateContent({
      model: "gemini-2.5-pro",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: { type: "string" }
            },
            youtubeSearchTerms: {
              type: "array",
              items: { type: "string" }
            },
            canBeRepaired: { type: "boolean" }
          },
          required: ["suggestions", "youtubeSearchTerms", "canBeRepaired"]
        }
      },
      contents: contents,
    });

    const rawJson = response.text;
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from model");
    }
  } catch (error) {
    console.error('Error getting reuse suggestions:', error);
    throw new Error(`Failed to get suggestions: ${error}`);
  }
}

export async function chatWithAI(userMessage: string, conversationHistory: { role: string; content: string }[]): Promise<string> {
  try {
    const systemPrompt = `You are an eco-friendly AI assistant helping users reuse, repair, and upcycle products. 
Be creative, encouraging, and practical with your suggestions. 
Always prioritize sustainability and environmental impact.
Keep responses concise but helpful.`;

    const contents = conversationHistory.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    }));

    contents.push({
      role: 'user',
      parts: [{ text: userMessage }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: contents,
    });

    return response.text || "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error('Error in AI chat:', error);
    throw new Error(`Chat failed: ${error}`);
  }
}
