import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - Firebase auth integrated
export const users = pgTable("users", {
  id: varchar("id").primaryKey(),
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  photoURL: text("photo_url"),
  ecoPoints: integer("eco_points").notNull().default(0),
  isRepairer: boolean("is_repairer").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Repairer profiles
export const repairers = pgTable("repairers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  skills: text("skills").array().notNull(),
  bio: text("bio"),
  location: text("location"),
  rating: integer("rating").notNull().default(0),
  completedRepairs: integer("completed_repairs").notNull().default(0),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Uploaded products for reuse/repair
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  imageUrl: text("image_url").notNull(),
  productType: text("product_type"),
  description: text("description"),
  status: text("status").notNull().default('uploaded'), // uploaded, getting_ideas, contacted_repairer, reused, donated
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Chat history with AI
export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  productId: varchar("product_id").references(() => products.id, { onDelete: 'cascade' }),
  messages: text("messages").notNull(), // JSON stringified array
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Marketplace listings (upcycled products)
export const marketplaceItems = pgTable("marketplace_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  repairerId: varchar("repairer_id").notNull().references(() => repairers.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  condition: text("condition").notNull(), // like-new, good, fair
  sold: boolean("sold").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Repair requests
export const repairRequests = pgTable("repair_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  repairerId: varchar("repairer_id").references(() => repairers.id, { onDelete: 'set null' }),
  productId: varchar("product_id").notNull().references(() => products.id, { onDelete: 'cascade' }),
  description: text("description").notNull(),
  status: text("status").notNull().default('pending'), // pending, accepted, completed, cancelled
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// EcoPoints transactions
export const ecoPointsTransactions = pgTable("eco_points_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  points: integer("points").notNull(),
  reason: text("reason").notNull(), // reused_item, donated_item, repair_completed
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  ecoPoints: true,
  createdAt: true,
});

export const insertRepairerSchema = createInsertSchema(repairers).omit({ 
  id: true, 
  rating: true,
  completedRepairs: true,
  createdAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({ 
  id: true, 
  status: true,
  createdAt: true,
});

export const insertChatSchema = createInsertSchema(chats).omit({ 
  id: true, 
  createdAt: true,
});

export const insertMarketplaceItemSchema = createInsertSchema(marketplaceItems).omit({ 
  id: true, 
  sold: true,
  createdAt: true,
});

export const insertRepairRequestSchema = createInsertSchema(repairRequests).omit({ 
  id: true, 
  status: true,
  createdAt: true,
});

export const insertEcoPointsTransactionSchema = createInsertSchema(ecoPointsTransactions).omit({ 
  id: true, 
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertRepairer = z.infer<typeof insertRepairerSchema>;
export type Repairer = typeof repairers.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertChat = z.infer<typeof insertChatSchema>;
export type Chat = typeof chats.$inferSelect;

export type InsertMarketplaceItem = z.infer<typeof insertMarketplaceItemSchema>;
export type MarketplaceItem = typeof marketplaceItems.$inferSelect;

export type InsertRepairRequest = z.infer<typeof insertRepairRequestSchema>;
export type RepairRequest = typeof repairRequests.$inferSelect;

export type InsertEcoPointsTransaction = z.infer<typeof insertEcoPointsTransactionSchema>;
export type EcoPointsTransaction = typeof ecoPointsTransactions.$inferSelect;
