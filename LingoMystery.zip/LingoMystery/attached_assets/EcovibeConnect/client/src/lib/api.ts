// API utility functions for Ecovibe
import { apiRequest } from "./queryClient";

export interface UploadProductResponse {
  success: boolean;
  analysis: string;
  imageUrl: string;
}

export interface ReuseSuggestionsResponse {
  success: boolean;
  suggestions: string[];
  youtubeSearchTerms: string[];
  canBeRepaired: boolean;
}

export interface ChatResponse {
  success: boolean;
  response: string;
}

export interface YouTubeLink {
  searchTerm: string;
  url: string;
  embedUrl: string;
}

export interface YouTubeSearchResponse {
  success: boolean;
  links: YouTubeLink[];
}

// Upload and analyze product image
export async function uploadProduct(imageFile: File): Promise<UploadProductResponse> {
  const formData = new FormData();
  formData.append('image', imageFile);

  const response = await fetch('/api/upload-product', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to upload image');
  }

  return response.json();
}

// Get reuse suggestions from AI
export async function getReuseSuggestions(
  productDescription: string,
  imageBase64?: string,
  mimeType?: string
): Promise<ReuseSuggestionsResponse> {
  const response = await apiRequest('POST', '/api/get-reuse-suggestions', {
    productDescription,
    imageBase64,
    mimeType,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to get suggestions');
  }

  return response.json();
}

// Chat with AI
export async function chatWithAI(
  message: string,
  conversationHistory: { role: string; content: string }[]
): Promise<ChatResponse> {
  const response = await apiRequest('POST', '/api/chat', {
    message,
    conversationHistory,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Chat failed');
  }

  return response.json();
}

// Get YouTube search links
export async function getYouTubeLinks(searchTerms: string[]): Promise<YouTubeSearchResponse> {
  const response = await apiRequest('POST', '/api/youtube-search', {
    searchTerms,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'YouTube search failed');
  }

  return response.json();
}

// User profile functions
export async function getUserProfile(userId: string) {
  const response = await apiRequest('GET', `/api/user/${userId}`, undefined);
  if (!response.ok) throw new Error('Failed to fetch user profile');
  return response.json();
}

// Repairer functions
export async function getRepairers() {
  const response = await apiRequest('GET', '/api/repairers', undefined);
  if (!response.ok) throw new Error('Failed to fetch repairers');
  return response.json();
}

export async function createRepairerProfile(data: {
  userId: string;
  skills: string[];
  bio?: string;
  location?: string;
  phone?: string;
  email?: string;
}) {
  const response = await apiRequest('POST', '/api/repairers', data);
  if (!response.ok) throw new Error('Failed to create repairer profile');
  return response.json();
}

// Marketplace functions
export async function getMarketplaceItems() {
  const response = await apiRequest('GET', '/api/marketplace', undefined);
  if (!response.ok) throw new Error('Failed to fetch marketplace items');
  return response.json();
}

export async function createMarketplaceItem(data: {
  repairerId: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  condition: 'like-new' | 'good' | 'fair';
}) {
  const response = await apiRequest('POST', '/api/marketplace', data);
  if (!response.ok) throw new Error('Failed to create marketplace item');
  return response.json();
}

// Repair request functions
export async function createRepairRequest(data: {
  userId: string;
  repairerId?: string;
  productId: string;
  description: string;
}) {
  const response = await apiRequest('POST', '/api/repair-requests', data);
  if (!response.ok) throw new Error('Failed to create repair request');
  return response.json();
}

// EcoPoints functions
export async function awardEcoPoints(data: {
  userId: string;
  points: number;
  reason: string;
}) {
  const response = await apiRequest('POST', '/api/eco-points', data);
  if (!response.ok) throw new Error('Failed to award EcoPoints');
  return response.json();
}
