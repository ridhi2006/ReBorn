import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Search, 
  SlidersHorizontal,
  Heart,
  ShoppingCart
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function MarketplacePage() {
  const [likedItems, setLikedItems] = useState<Set<string>>(new Set());

  const toggleLike = (id: string) => {
    setLikedItems(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const marketplaceItems = [
    {
      id: '1',
      title: 'Vintage Wooden Chair',
      price: 2500,
      category: 'Furniture',
      condition: 'Like New',
      imageUrl: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=400',
      seller: 'Raj Kumar',
    },
    {
      id: '2',
      title: 'Upcycled Denim Tote Bag',
      price: 800,
      category: 'Fashion',
      condition: 'Good',
      imageUrl: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=400',
      seller: 'Priya Sharma',
    },
    {
      id: '3',
      title: 'Restored Desk Lamp',
      price: 1200,
      category: 'Electronics',
      condition: 'Like New',
      imageUrl: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400',
      seller: 'Amit Patel',
    },
    {
      id: '4',
      title: 'Handcrafted Planter',
      price: 500,
      category: 'Home Decor',
      condition: 'Good',
      imageUrl: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400',
      seller: 'Raj Kumar',
    },
    {
      id: '5',
      title: 'Refurbished Bookshelf',
      price: 3500,
      category: 'Furniture',
      condition: 'Like New',
      imageUrl: 'https://images.unsplash.com/photo-1594620302200-9a762244a156?w=400',
      seller: 'Amit Patel',
    },
    {
      id: '6',
      title: 'Upcycled Wall Art',
      price: 1500,
      category: 'Home Decor',
      condition: 'Good',
      imageUrl: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=400',
      seller: 'Priya Sharma',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-2">Upcycle Marketplace</h1>
            <p className="text-lg text-muted-foreground">
              Discover beautifully restored and upcycled products
            </p>
          </div>

          {/* Filters */}
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input 
                placeholder="Search products..." 
                className="pl-10 h-12"
                data-testid="input-search-marketplace"
              />
            </div>
            <Select>
              <SelectTrigger className="w-full sm:w-48 h-12" data-testid="select-category">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="furniture">Furniture</SelectItem>
                <SelectItem value="electronics">Electronics</SelectItem>
                <SelectItem value="fashion">Fashion</SelectItem>
                <SelectItem value="decor">Home Decor</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger className="w-full sm:w-48 h-12" data-testid="select-condition">
                <SelectValue placeholder="Condition" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Conditions</SelectItem>
                <SelectItem value="like-new">Like New</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" className="h-12 w-12" data-testid="button-more-filters">
              <SlidersHorizontal className="w-5 h-5" />
            </Button>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {marketplaceItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <Card className="overflow-hidden hover-elevate cursor-pointer group h-full flex flex-col">
                  <div className="relative aspect-square overflow-hidden bg-muted">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      data-testid={`img-product-${item.id}`}
                    />
                    <Button
                      variant="secondary"
                      size="icon"
                      className="absolute top-3 right-3 rounded-full w-9 h-9"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleLike(item.id);
                      }}
                      data-testid={`button-like-${item.id}`}
                    >
                      <Heart 
                        className={`w-5 h-5 ${likedItems.has(item.id) ? 'fill-red-500 text-red-500' : ''}`}
                      />
                    </Button>
                    <Badge 
                      variant="secondary" 
                      className="absolute bottom-3 left-3"
                    >
                      {item.condition}
                    </Badge>
                  </div>
                  
                  <CardContent className="p-4 flex-1 flex flex-col">
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1 line-clamp-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground mb-2">by {item.seller}</p>
                      <Badge variant="outline" className="text-xs mb-3">
                        {item.category}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-between pt-3 border-t">
                      <span className="text-2xl font-bold">₹{item.price}</span>
                      <Button size="sm" className="gap-2" data-testid={`button-buy-${item.id}`}>
                        <ShoppingCart className="w-4 h-4" />
                        Buy
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
