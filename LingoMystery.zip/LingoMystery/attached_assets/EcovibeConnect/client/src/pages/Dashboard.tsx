import { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { 
  Upload, 
  Camera, 
  MessageSquare, 
  Wrench, 
  Leaf, 
  Recycle, 
  Award,
  TrendingUp,
  Image as ImageIcon
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useLocation } from 'wouter';

export default function Dashboard() {
  const { currentUser } = useAuth();
  const [, setLocation] = useLocation();
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const stats = [
    { 
      label: 'Products Reused', 
      value: '0', 
      icon: Recycle, 
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    { 
      label: 'CO₂ Saved', 
      value: '0 kg', 
      icon: Leaf, 
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50 dark:bg-emerald-950'
    },
    { 
      label: 'Repairs Done', 
      value: '0', 
      icon: Wrench, 
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-950'
    },
    { 
      label: 'EcoPoints', 
      value: '0', 
      icon: Award, 
      color: 'text-amber-600',
      bgColor: 'bg-amber-50 dark:bg-amber-950'
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold mb-2">
                Welcome back, {currentUser?.displayName?.split(' ')[0] || 'there'}! 👋
              </h1>
              <p className="text-lg text-muted-foreground">
                Ready to make a sustainable impact today?
              </p>
            </div>
            <Badge variant="secondary" className="hidden sm:flex items-center gap-2 px-4 py-2 text-base">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="font-semibold">Level 1 Eco-Warrior</span>
            </Badge>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="hover-elevate cursor-pointer transition-all duration-200">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                          <p className="text-3xl font-bold">{stat.value}</p>
                        </div>
                        <div className={`w-12 h-12 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                          <Icon className={`w-6 h-6 ${stat.color}`} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Upload Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-2xl">Upload Your Product</CardTitle>
              <CardDescription>
                Take a photo or upload an image of the product you want to reuse or repair
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                className={`relative border-2 border-dashed rounded-2xl p-8 md:p-12 text-center transition-all ${
                  isDragging 
                    ? 'border-primary bg-primary/5 scale-[0.98]' 
                    : uploadedImage 
                      ? 'border-primary' 
                      : 'border-border hover:border-primary/50'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileSelect}
                  className="hidden"
                  data-testid="input-file-upload"
                />

                {uploadedImage ? (
                  <div className="space-y-6">
                    <div className="relative inline-block">
                      <img
                        src={uploadedImage}
                        alt="Uploaded product"
                        className="max-h-64 rounded-xl shadow-lg"
                        data-testid="img-uploaded-preview"
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute -top-2 -right-2"
                        onClick={() => setUploadedImage(null)}
                        data-testid="button-remove-image"
                      >
                        ✕
                      </Button>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                      <Button
                        size="lg"
                        className="gap-2"
                        onClick={() => setLocation('/chatbot')}
                        data-testid="button-get-ai-ideas"
                      >
                        <MessageSquare className="w-5 h-5" />
                        Get AI Reuse Ideas
                      </Button>
                      <Button
                        size="lg"
                        variant="outline"
                        className="gap-2"
                        onClick={() => setLocation('/repairers')}
                        data-testid="button-contact-repairer"
                      >
                        <Wrench className="w-5 h-5" />
                        Contact Repairer
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 mb-2">
                      <Upload className="w-10 h-10 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">
                        Drop your photo here, or click to browse
                      </h3>
                      <p className="text-muted-foreground mb-6">
                        Supports: JPG, PNG, WebP (max 10MB)
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                      <Button
                        size="lg"
                        onClick={() => fileInputRef.current?.click()}
                        className="gap-2"
                        data-testid="button-browse-files"
                      >
                        <ImageIcon className="w-5 h-5" />
                        Browse Files
                      </Button>
                      <Button
                        size="lg"
                        variant="outline"
                        onClick={() => {
                          const input = fileInputRef.current;
                          if (input) {
                            input.capture = 'environment';
                            input.click();
                          }
                        }}
                        className="gap-2"
                        data-testid="button-take-photo"
                      >
                        <Camera className="w-5 h-5" />
                        Take Photo
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <h2 className="text-2xl font-bold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setLocation('/chatbot')}>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">AI Chat Assistant</h3>
                    <p className="text-sm text-muted-foreground">Get creative reuse ideas</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setLocation('/repairers')}>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950 flex items-center justify-center flex-shrink-0">
                    <Wrench className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Find Repairers</h3>
                    <p className="text-sm text-muted-foreground">Connect with experts</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate cursor-pointer transition-all" onClick={() => setLocation('/marketplace')}>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950 flex items-center justify-center flex-shrink-0">
                    <Recycle className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Browse Marketplace</h3>
                    <p className="text-sm text-muted-foreground">Discover upcycled items</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
