import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Wrench, 
  Star, 
  MapPin, 
  Phone, 
  Mail,
  CheckCircle,
  Search,
  Plus
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function RepairersPage() {
  const [showSignupForm, setShowSignupForm] = useState(false);

  const repairers = [
    {
      id: '1',
      name: 'Raj Kumar',
      skills: ['Electronics', 'Appliances', 'Furniture'],
      rating: 5,
      completedRepairs: 127,
      location: 'Delhi',
      bio: 'Expert in electronic repairs with 10+ years of experience',
    },
    {
      id: '2',
      name: 'Priya Sharma',
      skills: ['Clothing', 'Tailoring', 'Upholstery'],
      rating: 5,
      completedRepairs: 89,
      location: 'Mumbai',
      bio: 'Specialized in textile repairs and custom alterations',
    },
    {
      id: '3',
      name: 'Amit Patel',
      skills: ['Furniture', 'Wood Work', 'Restoration'],
      rating: 4,
      completedRepairs: 156,
      location: 'Bangalore',
      bio: 'Passionate about restoring vintage furniture',
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-4xl font-bold mb-2">Repairer Network</h1>
              <p className="text-lg text-muted-foreground">
                Connect with skilled professionals in your area
              </p>
            </div>
            <Button 
              onClick={() => setShowSignupForm(!showSignupForm)}
              className="gap-2"
              data-testid="button-toggle-repairer-signup"
            >
              <Plus className="w-5 h-5" />
              {showSignupForm ? 'View Repairers' : 'Become a Repairer'}
            </Button>
          </div>

          {showSignupForm ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Repairer Signup</CardTitle>
                  <CardDescription>
                    Join our network and start helping people repair their products
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="repairer-name">Full Name</Label>
                      <Input id="repairer-name" placeholder="Your name" data-testid="input-repairer-name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairer-location">Location</Label>
                      <Input id="repairer-location" placeholder="City, State" data-testid="input-repairer-location" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="repairer-skills">Skills (comma-separated)</Label>
                    <Input 
                      id="repairer-skills" 
                      placeholder="Electronics, Appliances, Furniture" 
                      data-testid="input-repairer-skills"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="repairer-bio">Bio</Label>
                    <Textarea 
                      id="repairer-bio" 
                      placeholder="Tell us about your experience and expertise..." 
                      rows={4}
                      data-testid="textarea-repairer-bio"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="repairer-phone">Phone</Label>
                      <Input id="repairer-phone" type="tel" placeholder="+91 98765 43210" data-testid="input-repairer-phone" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairer-email">Email</Label>
                      <Input id="repairer-email" type="email" placeholder="you@example.com" data-testid="input-repairer-email" />
                    </div>
                  </div>

                  <Button className="w-full h-12 font-semibold" data-testid="button-submit-repairer">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Register as Repairer
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <>
              {/* Search */}
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input 
                    placeholder="Search by name, skill, or location..." 
                    className="pl-10 h-12"
                    data-testid="input-search-repairers"
                  />
                </div>
              </div>

              {/* Repairers Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {repairers.map((repairer, index) => (
                  <motion.div
                    key={repairer.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="hover-elevate cursor-pointer h-full">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4 mb-4">
                          <Avatar className="w-14 h-14">
                            <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                              {repairer.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-lg mb-1">{repairer.name}</h3>
                            <div className="flex items-center gap-2 text-sm">
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                                <span className="font-medium">{repairer.rating}.0</span>
                              </div>
                              <span className="text-muted-foreground">
                                ({repairer.completedRepairs} repairs)
                              </span>
                            </div>
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground mb-4">
                          {repairer.bio}
                        </p>

                        <div className="flex items-center gap-2 mb-4 text-sm text-muted-foreground">
                          <MapPin className="w-4 h-4" />
                          <span>{repairer.location}</span>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-4">
                          {repairer.skills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex gap-2">
                          <Button className="flex-1" data-testid={`button-contact-${repairer.id}`}>
                            <Phone className="w-4 h-4 mr-2" />
                            Contact
                          </Button>
                          <Button variant="outline" size="icon">
                            <Mail className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </>
          )}
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
