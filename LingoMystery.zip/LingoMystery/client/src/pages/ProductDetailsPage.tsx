import { useState } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  CheckCircle2,
  Truck,
  Phone,
  Package,
  Leaf,
  Recycle,
  TreePine
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import qrCodeImage from '@assets/generated_images/Google_Pay_UPI_QR_placeholder_830b4e73.png';

interface DeliveryPartner {
  name: string;
  vehicle: string;
  eta: string;
  contact: string;
}

export default function ProductDetailsPage() {
  const [, params] = useRoute('/product/:id');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [liked, setLiked] = useState(false);
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [deliveryPartner, setDeliveryPartner] = useState<DeliveryPartner | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const productId = params?.id || '1';

  // Fetch product data from API
  const { data: product, isLoading, error } = useQuery({
    queryKey: [`/api/marketplace/${productId}`],
    enabled: !!productId
  });

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-muted-foreground">Loading product details...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Error state
  if (error || !product) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Navbar />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4 max-w-md">
            <h2 className="text-2xl font-bold">Product Not Found</h2>
            <p className="text-muted-foreground">
              Sorry, we couldn't find the product you're looking for.
            </p>
            <Button onClick={() => setLocation('/marketplace')}>
              Return to Marketplace
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const handlePaymentConfirm = async () => {
    setIsProcessing(true);
    
    try {
      // Call payment confirmation API
      const response = await apiRequest('POST', '/api/payment/confirm', {
        productId: product.id,
        buyerName: 'Guest User',
        amount: product.price
      });

      if (response.status === 'success') {
        setPaymentConfirmed(true);
        setShowSuccess(true);

        toast({
          title: "Payment Successful!",
          description: "Your payment has been received successfully.",
        });

        // Wait 3 seconds, then fetch delivery partner
        setTimeout(async () => {
          try {
            const deliveryResponse = await apiRequest('GET', '/api/delivery/assign', {});
            setDeliveryPartner(deliveryResponse);
          } catch (error) {
            console.error('Failed to assign delivery partner:', error);
            toast({
              title: "Error",
              description: "Failed to assign delivery partner. Please try again.",
              variant: "destructive"
            });
          }
        }, 3000);
      }
    } catch (error) {
      console.error('Payment confirmation failed:', error);
      toast({
        title: "Payment Failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6 gap-2"
            onClick={() => setLocation('/marketplace')}
            data-testid="button-back-marketplace"
          >
            <ArrowLeft className="w-4 h-4" />
            Return to Marketplace
          </Button>

          {/* Product Details - Two Column Layout */}
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-12">
            {/* Left Column - Image Gallery */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="space-y-4"
            >
              <div className="relative aspect-square rounded-xl overflow-hidden bg-muted group">
                <img 
                  src={product.imageUrl} 
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  data-testid="img-product-main"
                />
                <div className="absolute top-4 right-4 flex gap-2">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="rounded-full w-10 h-10 shadow-lg"
                    onClick={() => setLiked(!liked)}
                    data-testid="button-like-product"
                  >
                    <Heart className={`w-5 h-5 ${liked ? 'fill-red-500 text-red-500' : ''}`} />
                  </Button>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="rounded-full w-10 h-10 shadow-lg"
                    data-testid="button-share-product"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>
                <Badge 
                  variant="secondary" 
                  className="absolute bottom-4 left-4 text-sm px-3 py-1"
                >
                  {product.condition}
                </Badge>
              </div>

              {/* Sustainability Impact Stats */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-primary" />
                  Sustainability Impact
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center space-y-1">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mx-auto">
                      <Recycle className="w-6 h-6 text-primary" />
                    </div>
                    <p className="text-2xl font-bold text-primary">
                      {product.sustainabilityImpact.co2Saved}
                    </p>
                    <p className="text-xs text-muted-foreground">CO₂ Saved</p>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mx-auto">
                      <TreePine className="w-6 h-6 text-primary" />
                    </div>
                    <p className="text-2xl font-bold text-primary">
                      {product.sustainabilityImpact.waterSaved}
                    </p>
                    <p className="text-xs text-muted-foreground">Water Saved</p>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mx-auto">
                      <Package className="w-6 h-6 text-primary" />
                    </div>
                    <p className="text-2xl font-bold text-primary">
                      {product.sustainabilityImpact.wasteAvoided}
                    </p>
                    <p className="text-xs text-muted-foreground">Waste Avoided</p>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Right Column - Product Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
              className="space-y-6"
            >
              {/* Title and Seller */}
              <div>
                <div className="flex items-start justify-between mb-2">
                  <h1 className="text-3xl lg:text-4xl font-bold">{product.title}</h1>
                  <Badge variant="outline" className="text-xs">
                    {product.category}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-3 mb-4">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={product.sellerAvatar} />
                    <AvatarFallback>{product.seller[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Sold by {product.seller}</p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <span>⭐ {product.rating}</span>
                      <span>•</span>
                      <span>{product.reviewCount} reviews</span>
                      {product.verified && (
                        <>
                          <span>•</span>
                          <CheckCircle2 className="w-3 h-3 text-primary inline" />
                          <span className="text-primary">Verified</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-4xl font-bold text-primary mb-6">₹{product.price}</div>
              </div>

              <Separator />

              {/* Description */}
              <div>
                <h2 className="text-xl font-semibold mb-3">Description</h2>
                <p className="text-base text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Eco Story */}
              <div className="bg-primary/5 rounded-xl p-6 border border-primary/20">
                <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-primary" />
                  The Eco Story
                </h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {product.ecoStory}
                </p>
              </div>

              {/* Specifications */}
              <div>
                <h2 className="text-xl font-semibold mb-4">Specifications</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground mb-1">Condition</p>
                    <p className="font-semibold">{product.condition}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted">
                    <p className="text-xs text-muted-foreground mb-1">Material</p>
                    <p className="font-semibold">{product.material}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted col-span-2">
                    <p className="text-xs text-muted-foreground mb-1">Dimensions</p>
                    <p className="font-semibold">{product.dimensions}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Payment Section */}
          {!paymentConfirmed && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3 }}
            >
              <Card className="p-8 max-w-md mx-auto">
                <h2 className="text-2xl font-bold text-center mb-6">Complete Payment</h2>
                
                {/* QR Code */}
                <div className="flex flex-col items-center mb-6">
                  <div className="bg-white p-6 rounded-xl shadow-md mb-3">
                    <img 
                      src={qrCodeImage} 
                      alt="UPI QR Code"
                      className="w-48 h-48"
                      data-testid="img-qr-code"
                    />
                  </div>
                  <Badge variant="outline" className="mb-2">
                    Scan to pay with Google Pay / UPI
                  </Badge>
                  <p className="text-2xl font-bold text-primary">₹{product.price}</p>
                </div>

                <Separator className="my-6" />

                {/* Payment Button */}
                <Button 
                  className="w-full h-12 text-lg" 
                  onClick={handlePaymentConfirm}
                  disabled={isProcessing}
                  data-testid="button-confirm-payment"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    'Mark Payment as Done'
                  )}
                </Button>
              </Card>
            </motion.div>
          )}

          {/* Success Animation and Delivery Assignment */}
          <AnimatePresence>
            {showSuccess && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50"
                onClick={() => !deliveryPartner && setShowSuccess(false)}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: 'spring', duration: 0.5 }}
                  className="bg-card p-8 rounded-2xl shadow-2xl max-w-md w-full mx-4"
                  onClick={(e) => e.stopPropagation()}
                >
                  {!deliveryPartner ? (
                    <div className="text-center space-y-4">
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', delay: 0.2, duration: 0.6 }}
                        className="flex justify-center"
                      >
                        <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                          <CheckCircle2 className="w-12 h-12 text-primary" />
                        </div>
                      </motion.div>
                      <h2 className="text-3xl font-bold">Payment Successful!</h2>
                      <p className="text-muted-foreground">
                        Delivery partner is being assigned...
                      </p>
                      <div className="flex justify-center">
                        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                      </div>
                    </div>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4 }}
                      className="space-y-6"
                    >
                      <div className="text-center">
                        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                          <Truck className="w-8 h-8 text-primary" />
                        </div>
                        <h2 className="text-2xl font-bold mb-2">Delivery Partner Assigned!</h2>
                        <p className="text-sm text-muted-foreground">
                          Your order will be delivered soon
                        </p>
                      </div>

                      <Card className="p-6">
                        <div className="flex items-center gap-4 mb-4">
                          <Avatar className="w-14 h-14">
                            <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${deliveryPartner.name}`} />
                            <AvatarFallback>{deliveryPartner.name[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-semibold text-lg">{deliveryPartner.name}</p>
                            <p className="text-sm text-muted-foreground flex items-center gap-1">
                              <Truck className="w-3 h-3" />
                              {deliveryPartner.vehicle}
                            </p>
                          </div>
                          <Badge className="text-lg font-bold px-3 py-1">
                            {deliveryPartner.eta}
                          </Badge>
                        </div>

                        <Separator className="my-4" />

                        <div className="space-y-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Contact</span>
                            <span className="font-medium">{deliveryPartner.contact}</span>
                          </div>
                          <Button 
                            variant="outline" 
                            className="w-full gap-2"
                            data-testid="button-contact-delivery"
                          >
                            <Phone className="w-4 h-4" />
                            Contact Driver
                          </Button>
                        </div>
                      </Card>

                      <Button 
                        className="w-full"
                        onClick={() => {
                          setShowSuccess(false);
                          setLocation('/marketplace');
                        }}
                        data-testid="button-back-to-marketplace"
                      >
                        Back to Marketplace
                      </Button>
                    </motion.div>
                  )}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </main>

      <Footer />
    </div>
  );
}
