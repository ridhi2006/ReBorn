// Gemini AI integration for product analysis and reuse suggestions
import { GoogleGenerativeAI } from "@google/generative-ai";

if (!process.env.GEMINI_API_KEY) {
  console.warn('Missing GEMINI_API_KEY - Gemini features will be disabled');
}

const ai = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null;

export async function analyzeProductImage(imageBase64: string, mimeType: string): Promise<string> {
  try {
    if (!ai) {
      throw new Error('Gemini AI is not configured');
    }

    const model = ai.getGenerativeModel({ model: "gemini-1.5-flash" });

    const result = await model.generateContent([
      {
        inlineData: {
          data: imageBase64,
          mimeType: mimeType,
        },
      },
      `Analyze this product image and identify what it is. Provide a brief description of the item, its condition, and what type of product it appears to be. Be specific and concise.`,
    ]);

    const response = await result.response;
    return response.text() || "Could not analyze the image";
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw new Error(`Failed to analyze image: ${error}`);
  }
}

export async function getReuseSuggestions(productDescription: string, imageBase64?: string, mimeType?: string): Promise<{
  suggestions: string[];
  youtubeSearchTerms: string[];
  canBeRepaired: boolean;
}> {
  try {
    if (!ai) {
      throw new Error('Gemini AI is not configured');
    }

    const model = ai.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      generationConfig: { responseMimeType: "application/json" }
    });

    let contents: any[] = [];
    
    if (imageBase64 && mimeType) {
      contents.push({
        inlineData: {
          data: imageBase64,
          mimeType: mimeType,
        },
      });
    }

    const prompt = `Based on this product ${imageBase64 ? 'in the image' : ''}: ${productDescription}

Provide creative and practical reuse ideas for this item. For each suggestion:
1. Give a specific, actionable reuse idea
2. Suggest a YouTube search term that would help someone learn how to do it

Also determine if this item can be professionally repaired.

Respond in this exact JSON format:
{
  "suggestions": ["idea 1", "idea 2", "idea 3"],
  "youtubeSearchTerms": ["search term 1", "search term 2", "search term 3"],
  "canBeRepaired": true
}`;

    contents.push(prompt);

    const result = await model.generateContent(contents);
    const response = await result.response;
    const rawJson = response.text();
    
    if (rawJson) {
      return JSON.parse(rawJson);
    } else {
      throw new Error("Empty response from model");
    }
  } catch (error) {
    console.error('Error getting reuse suggestions:', error);
    throw new Error(`Failed to get suggestions: ${error}`);
  }
}

export async function chatWithAI(userMessage: string, conversationHistory: { role: string; content: string }[]): Promise<string> {
  try {
    if (!ai) {
      throw new Error('Gemini AI is not configured');
    }

    const systemPrompt = `You are an eco-friendly AI assistant helping users reuse, repair, and upcycle products. 
Be creative, encouraging, and practical with your suggestions. 
Always prioritize sustainability and environmental impact.
Keep responses concise but helpful.`;

    const model = ai.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      systemInstruction: systemPrompt
    });

    const chat = model.startChat({
      history: conversationHistory.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      }))
    });

    const result = await chat.sendMessage(userMessage);
    const response = await result.response;
    return response.text() || "I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error('Error in AI chat:', error);
    throw new Error(`Chat failed: ${error}`);
  }
}
