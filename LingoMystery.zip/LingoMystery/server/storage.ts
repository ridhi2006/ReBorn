import { randomUUID } from "crypto";

// In-memory storage for MVP
// In production, this would use Firebase Firestore

export interface User {
  id: string;
  email: string;
  displayName: string;
  photoURL?: string;
  ecoPoints: number;
  isRepairer: boolean;
  createdAt: Date;
}

export interface Repairer {
  id: string;
  userId: string;
  skills: string[];
  bio?: string;
  location?: string;
  rating: number;
  completedRepairs: number;
  phone?: string;
  email?: string;
  createdAt: Date;
}

export interface Product {
  id: string;
  userId: string;
  imageUrl: string;
  productType?: string;
  description?: string;
  status: 'uploaded' | 'getting_ideas' | 'contacted_repairer' | 'reused' | 'donated';
  createdAt: Date;
}

export interface Chat {
  id: string;
  userId: string;
  productId?: string;
  messages: { role: string; content: string }[];
  createdAt: Date;
}

export interface MarketplaceItem {
  id: string;
  repairerId: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  condition: 'like-new' | 'good' | 'fair';
  sold: boolean;
  createdAt: Date;
}

export interface RepairRequest {
  id: string;
  userId: string;
  repairerId?: string;
  productId: string;
  description: string;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  createdAt: Date;
}

export interface EcoPointsTransaction {
  id: string;
  userId: string;
  points: number;
  reason: string;
  createdAt: Date;
}

export interface Payment {
  id: string;
  productId: string;
  buyerName: string;
  amount: number;
  status: 'pending' | 'confirmed' | 'failed';
  createdAt: Date;
}

export interface DeliveryPartner {
  id: string;
  name: string;
  vehicle: string;
  eta: string;
  contact: string;
  available: boolean;
}

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: Omit<User, 'id' | 'ecoPoints' | 'isRepairer' | 'createdAt'>): Promise<User>;
  updateUserEcoPoints(userId: string, points: number): Promise<User | undefined>;

  // Repairers
  getRepairer(id: string): Promise<Repairer | undefined>;
  getRepairerByUserId(userId: string): Promise<Repairer | undefined>;
  getAllRepairers(): Promise<Repairer[]>;
  createRepairer(repairer: Omit<Repairer, 'id' | 'rating' | 'completedRepairs' | 'createdAt'>): Promise<Repairer>;

  // Products
  getProduct(id: string): Promise<Product | undefined>;
  getUserProducts(userId: string): Promise<Product[]>;
  createProduct(product: Omit<Product, 'id' | 'status' | 'createdAt'>): Promise<Product>;
  updateProductStatus(productId: string, status: Product['status']): Promise<Product | undefined>;

  // Chats
  getChat(id: string): Promise<Chat | undefined>;
  getUserChats(userId: string): Promise<Chat[]>;
  createChat(chat: Omit<Chat, 'id' | 'createdAt'>): Promise<Chat>;
  updateChatMessages(chatId: string, messages: Chat['messages']): Promise<Chat | undefined>;

  // Marketplace
  getMarketplaceItem(id: string): Promise<MarketplaceItem | undefined>;
  getAllMarketplaceItems(): Promise<MarketplaceItem[]>;
  createMarketplaceItem(item: Omit<MarketplaceItem, 'id' | 'sold' | 'createdAt'>): Promise<MarketplaceItem>;

  // Repair Requests
  getRepairRequest(id: string): Promise<RepairRequest | undefined>;
  getUserRepairRequests(userId: string): Promise<RepairRequest[]>;
  createRepairRequest(request: Omit<RepairRequest, 'id' | 'status' | 'createdAt'>): Promise<RepairRequest>;

  // EcoPoints Transactions
  createEcoPointsTransaction(transaction: Omit<EcoPointsTransaction, 'id' | 'createdAt'>): Promise<EcoPointsTransaction>;
  getUserTransactions(userId: string): Promise<EcoPointsTransaction[]>;

  // Payments
  createPayment(payment: Omit<Payment, 'id' | 'status' | 'createdAt'>): Promise<Payment>;
  confirmPayment(paymentId: string): Promise<Payment | undefined>;

  // Delivery Partners
  getAvailableDeliveryPartner(): Promise<DeliveryPartner | undefined>;
  getAllDeliveryPartners(): Promise<DeliveryPartner[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private repairers: Map<string, Repairer> = new Map();
  private products: Map<string, Product> = new Map();
  private chats: Map<string, Chat> = new Map();
  private marketplaceItems: Map<string, MarketplaceItem> = new Map();
  private repairRequests: Map<string, RepairRequest> = new Map();
  private ecoPointsTransactions: Map<string, EcoPointsTransaction> = new Map();
  private payments: Map<string, Payment> = new Map();
  private deliveryPartners: Map<string, DeliveryPartner> = new Map();

  constructor() {
    // Initialize with mock delivery partners
    this.initializeDeliveryPartners();
  }

  private initializeDeliveryPartners() {
    const partners: Omit<DeliveryPartner, 'id'>[] = [
      {
        name: 'Ravi Kumar',
        vehicle: 'Mini Truck',
        eta: '2 hrs',
        contact: '+91 98765 43210',
        available: true,
      },
      {
        name: 'Anita Sharma',
        vehicle: 'Bike',
        eta: '45 mins',
        contact: '+91 98765 43211',
        available: true,
      },
      {
        name: 'Porter Logistics',
        vehicle: 'Van',
        eta: '3 hrs',
        contact: '+91 98765 43212',
        available: true,
      },
    ];

    partners.forEach((partner) => {
      const id = randomUUID();
      this.deliveryPartners.set(id, { ...partner, id });
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(userData: Omit<User, 'id' | 'ecoPoints' | 'isRepairer' | 'createdAt'>): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...userData,
      id,
      ecoPoints: 10, // Welcome bonus!
      isRepairer: false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserEcoPoints(userId: string, points: number): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (user) {
      user.ecoPoints += points;
      this.users.set(userId, user);
    }
    return user;
  }

  // Repairers
  async getRepairer(id: string): Promise<Repairer | undefined> {
    return this.repairers.get(id);
  }

  async getRepairerByUserId(userId: string): Promise<Repairer | undefined> {
    return Array.from(this.repairers.values()).find(r => r.userId === userId);
  }

  async getAllRepairers(): Promise<Repairer[]> {
    return Array.from(this.repairers.values());
  }

  async createRepairer(repairerData: Omit<Repairer, 'id' | 'rating' | 'completedRepairs' | 'createdAt'>): Promise<Repairer> {
    const id = randomUUID();
    const repairer: Repairer = {
      ...repairerData,
      id,
      rating: 0,
      completedRepairs: 0,
      createdAt: new Date(),
    };
    this.repairers.set(id, repairer);
    
    // Update user to mark as repairer
    const user = this.users.get(repairerData.userId);
    if (user) {
      user.isRepairer = true;
      this.users.set(user.id, user);
    }
    
    return repairer;
  }

  // Products
  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getUserProducts(userId: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(p => p.userId === userId);
  }

  async createProduct(productData: Omit<Product, 'id' | 'status' | 'createdAt'>): Promise<Product> {
    const id = randomUUID();
    const product: Product = {
      ...productData,
      id,
      status: 'uploaded',
      createdAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProductStatus(productId: string, status: Product['status']): Promise<Product | undefined> {
    const product = this.products.get(productId);
    if (product) {
      product.status = status;
      this.products.set(productId, product);
    }
    return product;
  }

  // Chats
  async getChat(id: string): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async getUserChats(userId: string): Promise<Chat[]> {
    return Array.from(this.chats.values()).filter(c => c.userId === userId);
  }

  async createChat(chatData: Omit<Chat, 'id' | 'createdAt'>): Promise<Chat> {
    const id = randomUUID();
    const chat: Chat = {
      ...chatData,
      id,
      createdAt: new Date(),
    };
    this.chats.set(id, chat);
    return chat;
  }

  async updateChatMessages(chatId: string, messages: Chat['messages']): Promise<Chat | undefined> {
    const chat = this.chats.get(chatId);
    if (chat) {
      chat.messages = messages;
      this.chats.set(chatId, chat);
    }
    return chat;
  }

  // Marketplace
  async getMarketplaceItem(id: string): Promise<MarketplaceItem | undefined> {
    return this.marketplaceItems.get(id);
  }

  async getAllMarketplaceItems(): Promise<MarketplaceItem[]> {
    return Array.from(this.marketplaceItems.values()).filter(item => !item.sold);
  }

  async createMarketplaceItem(itemData: Omit<MarketplaceItem, 'id' | 'sold' | 'createdAt'>): Promise<MarketplaceItem> {
    const id = randomUUID();
    const item: MarketplaceItem = {
      ...itemData,
      id,
      sold: false,
      createdAt: new Date(),
    };
    this.marketplaceItems.set(id, item);
    return item;
  }

  // Repair Requests
  async getRepairRequest(id: string): Promise<RepairRequest | undefined> {
    return this.repairRequests.get(id);
  }

  async getUserRepairRequests(userId: string): Promise<RepairRequest[]> {
    return Array.from(this.repairRequests.values()).filter(r => r.userId === userId);
  }

  async createRepairRequest(requestData: Omit<RepairRequest, 'id' | 'status' | 'createdAt'>): Promise<RepairRequest> {
    const id = randomUUID();
    const request: RepairRequest = {
      ...requestData,
      id,
      status: 'pending',
      createdAt: new Date(),
    };
    this.repairRequests.set(id, request);
    return request;
  }

  // EcoPoints Transactions
  async createEcoPointsTransaction(transactionData: Omit<EcoPointsTransaction, 'id' | 'createdAt'>): Promise<EcoPointsTransaction> {
    const id = randomUUID();
    const transaction: EcoPointsTransaction = {
      ...transactionData,
      id,
      createdAt: new Date(),
    };
    this.ecoPointsTransactions.set(id, transaction);
    
    // Update user's total points
    await this.updateUserEcoPoints(transactionData.userId, transactionData.points);
    
    return transaction;
  }

  async getUserTransactions(userId: string): Promise<EcoPointsTransaction[]> {
    return Array.from(this.ecoPointsTransactions.values()).filter(t => t.userId === userId);
  }

  // Payments
  async createPayment(paymentData: Omit<Payment, 'id' | 'status' | 'createdAt'>): Promise<Payment> {
    const id = randomUUID();
    const payment: Payment = {
      ...paymentData,
      id,
      status: 'pending',
      createdAt: new Date(),
    };
    this.payments.set(id, payment);
    return payment;
  }

  async confirmPayment(paymentId: string): Promise<Payment | undefined> {
    const payment = this.payments.get(paymentId);
    if (payment) {
      payment.status = 'confirmed';
      this.payments.set(paymentId, payment);
    }
    return payment;
  }

  // Delivery Partners
  async getAvailableDeliveryPartner(): Promise<DeliveryPartner | undefined> {
    const availablePartners = Array.from(this.deliveryPartners.values()).filter(p => p.available);
    if (availablePartners.length === 0) return undefined;
    
    // Randomly select one
    const randomIndex = Math.floor(Math.random() * availablePartners.length);
    return availablePartners[randomIndex];
  }

  async getAllDeliveryPartners(): Promise<DeliveryPartner[]> {
    return Array.from(this.deliveryPartners.values());
  }
}

export const storage = new MemStorage();
