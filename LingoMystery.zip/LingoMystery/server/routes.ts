import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { analyzeProductImage, getReuseSuggestions, chatWithAI } from "./gemini";
import { storage } from "./storage";

// Configure multer for image uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Image upload and analysis endpoint
  app.post("/api/upload-product", upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const imageBase64 = req.file.buffer.toString('base64');
      const mimeType = req.file.mimetype;

      // Analyze the image
      const analysis = await analyzeProductImage(imageBase64, mimeType);

      res.json({
        success: true,
        analysis,
        imageUrl: `data:${mimeType};base64,${imageBase64}`, // In production, upload to Firebase Storage
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      res.status(500).json({ message: error.message || "Failed to process image" });
    }
  });

  // Get AI reuse suggestions
  app.post("/api/get-reuse-suggestions", async (req, res) => {
    try {
      const { productDescription, imageBase64, mimeType } = req.body;

      if (!productDescription) {
        return res.status(400).json({ message: "Product description is required" });
      }

      const suggestions = await getReuseSuggestions(productDescription, imageBase64, mimeType);

      res.json({
        success: true,
        ...suggestions,
      });
    } catch (error: any) {
      console.error('Suggestions error:', error);
      res.status(500).json({ message: error.message || "Failed to get suggestions" });
    }
  });

  // AI chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, conversationHistory } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const history = conversationHistory || [];
      const response = await chatWithAI(message, history);

      res.json({
        success: true,
        response,
      });
    } catch (error: any) {
      console.error('Chat error:', error);
      res.status(500).json({ message: error.message || "Chat failed" });
    }
  });

  // Get YouTube search results (using YouTube Data API would require additional setup)
  // For now, we'll return YouTube search URLs
  app.post("/api/youtube-search", async (req, res) => {
    try {
      const { searchTerms } = req.body;

      if (!searchTerms || !Array.isArray(searchTerms)) {
        return res.status(400).json({ message: "Search terms array is required" });
      }

      const youtubeLinks = searchTerms.map((term: string) => ({
        searchTerm: term,
        url: `https://www.youtube.com/results?search_query=${encodeURIComponent(term)}`,
        embedUrl: `https://www.youtube.com/embed/?search_query=${encodeURIComponent(term)}`,
      }));

      res.json({
        success: true,
        links: youtubeLinks,
      });
    } catch (error: any) {
      console.error('YouTube search error:', error);
      res.status(500).json({ message: error.message || "Search failed" });
    }
  });

  // Placeholder endpoints for future Firebase Firestore integration
  
  // Get user profile
  app.get("/api/user/:userId", async (req, res) => {
    try {
      // TODO: Fetch from Firestore
      res.json({
        success: true,
        user: {
          id: req.params.userId,
          ecoPoints: 0,
          productsReused: 0,
          co2Saved: 0,
          repairsCompleted: 0,
        },
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get repairers
  app.get("/api/repairers", async (req, res) => {
    try {
      // TODO: Fetch from Firestore
      res.json({
        success: true,
        repairers: [],
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create repairer profile
  app.post("/api/repairers", async (req, res) => {
    try {
      const { userId, skills, bio, location, phone, email } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Repairer profile created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get marketplace items
  app.get("/api/marketplace", async (req, res) => {
    try {
      // Return mock marketplace items for now
      const items = [
        {
          id: '1',
          title: 'Vintage Wooden Chair',
          price: 2500,
          category: 'Furniture',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=800',
          seller: 'Raj Kumar',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Raj',
          description: 'This beautiful vintage wooden chair has been lovingly restored to its former glory. The rich mahogany wood has been carefully sanded and refinished, revealing stunning natural grain patterns. Perfect for adding character to any dining room or study.',
          ecoStory: 'Rescued from a demolition site, this chair was destined for landfill. Through meticulous restoration work, we\'ve given it a second life while saving approximately 15kg of CO2 emissions compared to manufacturing a new chair. Every scratch tells a story of its 40-year history.',
          material: 'Solid Mahogany Wood',
          dimensions: '45cm W x 50cm D x 85cm H',
          sustainabilityImpact: {
            co2Saved: '15kg',
            waterSaved: '250L',
            wasteAvoided: '20kg'
          },
          rating: 4.8,
          reviewCount: 24,
          verified: true
        },
        {
          id: '2',
          title: 'Upcycled Denim Tote Bag',
          price: 800,
          category: 'Fashion',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800',
          seller: 'Priya Sharma',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya',
          description: 'Handcrafted tote bag made entirely from reclaimed denim jeans. Features sturdy handles, reinforced stitching, and multiple interior pockets. Each bag is unique, showcasing different shades of blue denim.',
          ecoStory: 'Created from 3 pairs of discarded jeans collected from textile recycling centers. This bag prevents textile waste while reducing the water and chemical pollution associated with new denim production.',
          material: 'Upcycled Denim',
          dimensions: '40cm W x 35cm H x 10cm D',
          sustainabilityImpact: {
            co2Saved: '8kg',
            waterSaved: '7000L',
            wasteAvoided: '1.5kg'
          },
          rating: 4.6,
          reviewCount: 18,
          verified: true
        },
        {
          id: '3',
          title: 'Restored Desk Lamp',
          price: 1200,
          category: 'Electronics',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800',
          seller: 'Amit Patel',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amit',
          description: 'Vintage desk lamp completely restored with modern LED bulb and new wiring. Features adjustable arm and classic metal finish. Perfect for home offices or reading nooks.',
          ecoStory: 'This 1970s lamp was rescued from e-waste. We replaced outdated components with energy-efficient LED technology, extending its life by decades while reducing energy consumption by 80%.',
          material: 'Steel & Brass',
          dimensions: '15cm base, 45cm max height',
          sustainabilityImpact: {
            co2Saved: '12kg',
            waterSaved: '150L',
            wasteAvoided: '3kg'
          },
          rating: 4.9,
          reviewCount: 32,
          verified: true
        },
        {
          id: '4',
          title: 'Handcrafted Planter',
          price: 500,
          category: 'Home Decor',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800',
          seller: 'Raj Kumar',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Raj',
          description: 'Beautiful ceramic planter upcycled from reclaimed materials. Features drainage holes and a rustic, hand-painted finish. Ideal for small to medium-sized plants.',
          ecoStory: 'Made from broken pottery pieces collected from local artisan workshops. Each planter is hand-assembled and painted, preventing ceramic waste while creating unique home decor.',
          material: 'Reclaimed Ceramic',
          dimensions: '20cm diameter x 18cm H',
          sustainabilityImpact: {
            co2Saved: '3kg',
            waterSaved: '50L',
            wasteAvoided: '2kg'
          },
          rating: 4.5,
          reviewCount: 15,
          verified: true
        },
        {
          id: '5',
          title: 'Refurbished Bookshelf',
          price: 3500,
          category: 'Furniture',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1594620302200-9a762244a156?w=800',
          seller: 'Amit Patel',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amit',
          description: 'Sturdy wooden bookshelf with five adjustable shelves. Completely refinished with eco-friendly varnish. Can hold up to 150 books or display items.',
          ecoStory: 'Salvaged from an office renovation, this bookshelf was stripped and refinished using low-VOC, water-based products. Choosing refurbished furniture prevents deforestation and reduces manufacturing emissions.',
          material: 'Solid Pine Wood',
          dimensions: '90cm W x 180cm H x 30cm D',
          sustainabilityImpact: {
            co2Saved: '45kg',
            waterSaved: '500L',
            wasteAvoided: '35kg'
          },
          rating: 4.7,
          reviewCount: 21,
          verified: true
        },
        {
          id: '6',
          title: 'Upcycled Wall Art',
          price: 1500,
          category: 'Home Decor',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800',
          seller: 'Priya Sharma',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya',
          description: 'One-of-a-kind wall art created from reclaimed wood pieces. Features an abstract design with natural wood tones. Ready to hang with included mounting hardware.',
          ecoStory: 'Crafted from wood scraps collected from furniture workshops and construction sites. Each piece of wood is cleaned, sanded, and arranged into unique artistic compositions, preventing wood waste.',
          material: 'Reclaimed Wood',
          dimensions: '80cm W x 60cm H x 3cm D',
          sustainabilityImpact: {
            co2Saved: '6kg',
            waterSaved: '80L',
            wasteAvoided: '4kg'
          },
          rating: 4.8,
          reviewCount: 19,
          verified: true
        }
      ];
      
      res.json({
        success: true,
        items,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get single marketplace item by ID
  app.get("/api/marketplace/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Mock marketplace items
      const items = [
        {
          id: '1',
          title: 'Vintage Wooden Chair',
          price: 2500,
          category: 'Furniture',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=800',
          seller: 'Raj Kumar',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Raj',
          description: 'This beautiful vintage wooden chair has been lovingly restored to its former glory. The rich mahogany wood has been carefully sanded and refinished, revealing stunning natural grain patterns. Perfect for adding character to any dining room or study.',
          ecoStory: 'Rescued from a demolition site, this chair was destined for landfill. Through meticulous restoration work, we\'ve given it a second life while saving approximately 15kg of CO2 emissions compared to manufacturing a new chair. Every scratch tells a story of its 40-year history.',
          material: 'Solid Mahogany Wood',
          dimensions: '45cm W x 50cm D x 85cm H',
          sustainabilityImpact: {
            co2Saved: '15kg',
            waterSaved: '250L',
            wasteAvoided: '20kg'
          },
          rating: 4.8,
          reviewCount: 24,
          verified: true
        },
        {
          id: '2',
          title: 'Upcycled Denim Tote Bag',
          price: 800,
          category: 'Fashion',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800',
          seller: 'Priya Sharma',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya',
          description: 'Handcrafted tote bag made entirely from reclaimed denim jeans. Features sturdy handles, reinforced stitching, and multiple interior pockets. Each bag is unique, showcasing different shades of blue denim.',
          ecoStory: 'Created from 3 pairs of discarded jeans collected from textile recycling centers. This bag prevents textile waste while reducing the water and chemical pollution associated with new denim production.',
          material: 'Upcycled Denim',
          dimensions: '40cm W x 35cm H x 10cm D',
          sustainabilityImpact: {
            co2Saved: '8kg',
            waterSaved: '7000L',
            wasteAvoided: '1.5kg'
          },
          rating: 4.6,
          reviewCount: 18,
          verified: true
        },
        {
          id: '3',
          title: 'Restored Desk Lamp',
          price: 1200,
          category: 'Electronics',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800',
          seller: 'Amit Patel',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amit',
          description: 'Vintage desk lamp completely restored with modern LED bulb and new wiring. Features adjustable arm and classic metal finish. Perfect for home offices or reading nooks.',
          ecoStory: 'This 1970s lamp was rescued from e-waste. We replaced outdated components with energy-efficient LED technology, extending its life by decades while reducing energy consumption by 80%.',
          material: 'Steel & Brass',
          dimensions: '15cm base, 45cm max height',
          sustainabilityImpact: {
            co2Saved: '12kg',
            waterSaved: '150L',
            wasteAvoided: '3kg'
          },
          rating: 4.9,
          reviewCount: 32,
          verified: true
        },
        {
          id: '4',
          title: 'Handcrafted Planter',
          price: 500,
          category: 'Home Decor',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800',
          seller: 'Raj Kumar',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Raj',
          description: 'Beautiful ceramic planter upcycled from reclaimed materials. Features drainage holes and a rustic, hand-painted finish. Ideal for small to medium-sized plants.',
          ecoStory: 'Made from broken pottery pieces collected from local artisan workshops. Each planter is hand-assembled and painted, preventing ceramic waste while creating unique home decor.',
          material: 'Reclaimed Ceramic',
          dimensions: '20cm diameter x 18cm H',
          sustainabilityImpact: {
            co2Saved: '3kg',
            waterSaved: '50L',
            wasteAvoided: '2kg'
          },
          rating: 4.5,
          reviewCount: 15,
          verified: true
        },
        {
          id: '5',
          title: 'Refurbished Bookshelf',
          price: 3500,
          category: 'Furniture',
          condition: 'Like New',
          imageUrl: 'https://images.unsplash.com/photo-1594620302200-9a762244a156?w=800',
          seller: 'Amit Patel',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amit',
          description: 'Sturdy wooden bookshelf with five adjustable shelves. Completely refinished with eco-friendly varnish. Can hold up to 150 books or display items.',
          ecoStory: 'Salvaged from an office renovation, this bookshelf was stripped and refinished using low-VOC, water-based products. Choosing refurbished furniture prevents deforestation and reduces manufacturing emissions.',
          material: 'Solid Pine Wood',
          dimensions: '90cm W x 180cm H x 30cm D',
          sustainabilityImpact: {
            co2Saved: '45kg',
            waterSaved: '500L',
            wasteAvoided: '35kg'
          },
          rating: 4.7,
          reviewCount: 21,
          verified: true
        },
        {
          id: '6',
          title: 'Upcycled Wall Art',
          price: 1500,
          category: 'Home Decor',
          condition: 'Good',
          imageUrl: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800',
          seller: 'Priya Sharma',
          sellerAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Priya',
          description: 'One-of-a-kind wall art created from reclaimed wood pieces. Features an abstract design with natural wood tones. Ready to hang with included mounting hardware.',
          ecoStory: 'Crafted from wood scraps collected from furniture workshops and construction sites. Each piece of wood is cleaned, sanded, and arranged into unique artistic compositions, preventing wood waste.',
          material: 'Reclaimed Wood',
          dimensions: '80cm W x 60cm H x 3cm D',
          sustainabilityImpact: {
            co2Saved: '6kg',
            waterSaved: '80L',
            wasteAvoided: '4kg'
          },
          rating: 4.8,
          reviewCount: 19,
          verified: true
        }
      ];
      
      const item = items.find(i => i.id === id);
      
      if (!item) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(item);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create marketplace item
  app.post("/api/marketplace", async (req, res) => {
    try {
      const { repairerId, title, description, price, imageUrl, category, condition } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Marketplace item created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create repair request
  app.post("/api/repair-requests", async (req, res) => {
    try {
      const { userId, repairerId, productId, description } = req.body;
      
      // TODO: Save to Firestore
      res.json({
        success: true,
        message: "Repair request created successfully",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Award EcoPoints
  app.post("/api/eco-points", async (req, res) => {
    try {
      const { userId, points, reason } = req.body;
      
      // TODO: Save to Firestore and update user's total
      res.json({
        success: true,
        message: "EcoPoints awarded successfully",
        newTotal: points,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Payment confirmation endpoint
  app.post("/api/payment/confirm", async (req, res) => {
    try {
      const { productId, buyerName, amount } = req.body;

      if (!productId || !buyerName || !amount) {
        return res.status(400).json({ 
          status: "error",
          message: "Missing required fields: productId, buyerName, amount" 
        });
      }

      // Create payment record
      const payment = await storage.createPayment({
        productId,
        buyerName,
        amount,
      });

      // Confirm payment
      await storage.confirmPayment(payment.id);

      console.log(`Payment confirmed for product ${productId} - Amount: ₹${amount} by ${buyerName}`);

      res.json({
        status: "success",
        message: "Payment received successfully!",
        paymentId: payment.id,
      });
    } catch (error: any) {
      console.error('Payment confirmation error:', error);
      res.status(500).json({ 
        status: "error",
        message: error.message || "Payment confirmation failed" 
      });
    }
  });

  // Delivery partner assignment endpoint
  app.get("/api/delivery/assign", async (req, res) => {
    try {
      // Get a random available delivery partner
      const partner = await storage.getAvailableDeliveryPartner();

      if (!partner) {
        return res.status(404).json({ 
          message: "No delivery partners available at the moment" 
        });
      }

      console.log(`Delivery partner assigned: ${partner.name} - ETA: ${partner.eta}`);

      // Return partner details without the internal ID and availability status
      res.json({
        name: partner.name,
        vehicle: partner.vehicle,
        eta: partner.eta,
        contact: partner.contact,
      });
    } catch (error: any) {
      console.error('Delivery assignment error:', error);
      res.status(500).json({ 
        message: error.message || "Failed to assign delivery partner" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
